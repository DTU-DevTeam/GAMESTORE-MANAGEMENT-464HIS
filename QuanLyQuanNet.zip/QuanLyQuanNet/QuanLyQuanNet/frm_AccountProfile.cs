﻿using QuanLyQuanNet.DAO;
using QuanLyQuanNet.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanNet
{
    public partial class frm_AccountProfile : Form
    {
        private Account loginAccount;
        public Account LoginAccount
        {
            get { return loginAccount; }
            set { loginAccount = value; ChangeAccount(loginAccount); }
        }
        public frm_AccountProfile(Account acc)
        {
            InitializeComponent();
            LoginAccount = acc;
        }
        void ChangeAccount(Account acc)
        {
            txbUserName.Text = LoginAccount.UserName;
            txbDisplayName.Text = LoginAccount.DisplayName;
        }
        void UpdateAccount()
        {
            string displayName = txbDisplayName.Text;
            string userName = txbUserName.Text;
            string passWord = txbPassWord.Text;
            string newPassWord = txbNewPass.Text;
            string reEnterPassWord = txbReEnterPass.Text;
            if (!newPassWord.Equals(reEnterPassWord))
            {
                MessageBox.Show("Mật khẩu không khớp !");
            }
            else
            {
                if (AccountDao.Instance.UpdateAccount(userName, displayName, passWord, newPassWord))
                {
                    MessageBox.Show("Cập nhật thành công !");
                    if (updateAccount != null)
                    {
                        updateAccount(this,new AccountEvent(AccountDao.Instance.GetAccountByUserName(userName)));
                    }
                }
                else
                {
                    MessageBox.Show("Vui lòng điền đúng mật khẩu !");
                }
            }
        }
        private event EventHandler<AccountEvent> updateAccount;
        public event EventHandler<AccountEvent> UpdateAccount1
        {
            add { updateAccount += value; }
            remove { updateAccount -= value; }
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateAccount();
        }
    }
    public class AccountEvent : EventArgs
    {
        private Account account;
        public Account Account
        {
            get { return account; }
            set { account = value; }
        }
        public AccountEvent(Account acc)
        {
            this.Account = acc;
        }
    }
}
